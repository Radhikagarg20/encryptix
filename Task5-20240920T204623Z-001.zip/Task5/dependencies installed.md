# Node js dependencies
### bcrypt
- hasing password

### cloudinary
- for uploading /modifying resume

### cookie-parser
- cookie for user authorisation

### cors
- to connect frontend and backend

### dotenv
- environment variables

### express
- node framework

### express-fileupload
- help in uploading file to cloudinary

### jsonwebtoken
- for authentication and authorization purposes

### mongoose
- mogodb database

### validator
- for validation


# React Dependencies

- react-router-dom
- axios
- react-icons
- react-hot-toast
